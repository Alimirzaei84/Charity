# Project Title

Charity

## Description
A web application that allows users to donate to charity organizations.

This project is for learning API creation and django rest framework.


## Demo
Live Demo



## Author
ALI MIRZAEI 

## Installation

# Clone the repository
git clone https://github.com/yourusername/yourproject.git

# Navigate to the project directory
cd yourproject

# Install dependencies
npm install

# Run the project
npm start
